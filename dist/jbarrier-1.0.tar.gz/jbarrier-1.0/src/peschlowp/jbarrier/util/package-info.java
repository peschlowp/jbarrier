/**
 * Utilities used by some barrier implementations. Currently this package
 * contains only a single class with a few methods for calculating powers-of-two
 * related stuff.
 */
package peschlowp.jbarrier.util;